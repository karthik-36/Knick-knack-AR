This model is free for use.
You are not allowed to present this model on other websites than turbosquid.com, 3d-modeler.info, 3d-modeler.net.
If you present this model on other websites, i'll introduce legal steps.
You are not allowed to modify this model without my permission!
This model is only for private use, if you want to use this model for commercial usage you have to contact me via eMail (info@3d-modeler.info).

(c) Soenke 2007